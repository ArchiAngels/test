
console.log('AFTER LOAD');

const check_box = document.getElementsByClassName('custom_check_box');
const sort_by = document.getElementsByClassName('sort_by');
let sort_icons_count ={
    price:0,
    years:0,
    itemPrice:document.getElementsByClassName('price'),
    itemYears:document.getElementsByClassName('years')
}
let like_cat = false;


if(window.innerWidth <= 850){

    const logo = document.getElementsByClassName('logo');
    const exit_logo = document.getElementsByClassName('darkscene_wrap_exit');
    let body = document.getElementsByTagName('body');
    let darkscene = document.getElementsByClassName('darkscene');

    logo[0].addEventListener('click',()=>{
        darkscene[0].classList.toggle('width');
        body[0].classList.toggle('stop');
        for(let item = 0; item < darkscene[0].childElementCount;item++){
            darkscene[0].children[item].classList.toggle('hide');
        }
        darkscene[0].classList.toggle('show');
    })
    exit_logo[0].addEventListener('click',()=>{

        darkscene[0].classList.toggle('width');
        body[0].classList.toggle('stop');
        for(let item = 0; item < darkscene[0].childElementCount;item++){
            darkscene[0].children[item].classList.toggle('hide');
        }
        darkscene[0].classList.toggle('show');
        
    })
    window,addEventListener('scroll',()=>{
        if(window.scrollY > 252){
            logo[0].style.position = 'fixed';
        } else{
            logo[0].style.position = '';
        }
    })
}

window.addEventListener('click',(e)=>{
    for(let i =0; i <e.target.classList.length;i++){

        if(e.target.classList[i] == 'like'){
            if(e.target.tagName == 'path'){
                e.target.parentElement.classList.toggle('liked');
                // console.log(e.target.parentElement.getAttribute('data-id'));
                pop_up(e.target.parentElement.getAttribute('data-id'));
                // like_cat = true;
                break;
        
            }else if(e.target.tagName == 'svg'){
                e.target.classList.toggle('liked');
                // like_cat = true;
                // console.log(e.target.getAttribute('data-id'));
                pop_up(e.target.getAttribute('data-id'));
                break;
        
            }else if(e.target.tagName == 'DIV' ){
                e.target.children[0].classList.toggle('liked');
                // like_cat = true;
                // console.log(e.target.children[0].getAttribute('data-id'));
                pop_up(e.target.children[0].getAttribute('data-id'));
                break;
            }

            function pop_up(n){
                let new_liked_id = n;
                let new_div = document.createElement('DIV');
                    let new_p = document.createElement('p');
                    new_div.classList.add('pop_up');
                for(let i =0; i < array_with_cats.length;i++){
                    if(array_with_cats[i].id == new_liked_id){
                        if(array_with_cats[i].liked){
                            // dislike
                            array_with_cats[i].liked = false;
                            new_p.innerText = 'Убрано из избранных!';
                            new_div.classList.add('remove');
                        }else{
                            //like
                            array_with_cats[i].liked = true;
                            new_p.innerText = 'Добавлено в избранные!';
                            new_div.classList.add('add');
                        }
                        // console.log(array_with_cats[i].liked);
                        new_div.appendChild(new_p);
                        array_with_cats[i].onPage[0].getElementsByClassName('top_info_about_cat')[0].appendChild(new_div);
                            setTimeout(()=>{
                                array_with_cats[i].onPage[0].getElementsByClassName('top_info_about_cat')[0].removeChild(new_div);
                            },1000);
                        break;
                        
                    }
                }
            }

        }    
    }
    if(e.target == check_box[0]){
        check_box_func();
    } else if(e.target == check_box[0].children[0].children[0]){
        check_box_func();
    }  else if(e.target == check_box[0].children[0]){
        check_box_func();
    }else if(e.target == check_box[0].children[1]){
        check_box_func();
    }

    function check_box_func(){
        check_box[0].children[0].classList.toggle('not_checked_bb');
        check_box[0].children[0].classList.toggle('checked_bb');
        check_box[0].children[0].children[0].classList.toggle('not_checked_smb');
        check_box[0].children[0].children[0].classList.toggle('checked_smb');
    }

    if(e.target == sort_by[0].children[1] || e.target == sort_by[0].children[1].children[0] || e.target == sort_by[0].children[1].children[1]){
        // console.log('price');
        place_for_cats[0].innerHTML = '';
        sort_icons_count.price++;
        cat_1.sort_by_price();
        sort_icons_count.itemPrice[0].style.transform = `rotate(${45-(sort_icons_count.price*180)}deg)`;
        sort_icons_count.itemYears[0].style.transform = `rotate(${0}deg)`;
        if(sort_icons_count.price%2 == 0){
            // console.log('price 4et');
            cat_1.insert_all_cats_low_to_high();
        }
        else{
            // console.log('price ne4et');
            cat_1.insert_all_cats_high_to_low();
        }
        // sort_by[0].children[1].children[1].classList.toggle
    }else if(e.target == sort_by[0].children[2] || e.target == sort_by[0].children[2].children[0] || e.target == sort_by[0].children[2].children[1]){
        // console.log('years');
        place_for_cats[0].innerHTML = '';
        sort_icons_count.years++;
        cat_1.sort_by_years();
        sort_icons_count.itemYears[0].style.transform = `rotate(${45-(sort_icons_count.years*180)}deg)`;
        sort_icons_count.itemPrice[0].style.transform = `rotate(${0}deg)`;
        if(sort_icons_count.years%2 == 0){
            // console.log('years 4et');
            cat_1.insert_all_cats_low_to_high();
        }
        else{

            // console.log('years ne4et');
            cat_1.insert_all_cats_high_to_low();
        }
        
    }
})

let new_id_cat = 0;
class Cat{
    constructor(options){
        this.price = options.price;
        this.photo = options.photo;
        this.name = options.name;
        this.color = options.color;
        this.discount = options.discount;
        this.years = options.years;
        this.liked = options.liked;
        this.can_buy = options.can_buy
        this.id = new_id_cat;
        this.isInsered = false;
        // console.log('My new cat',this);
        array_with_cats.push(this);
        this.make_price();
        new_id_cat++;
    }
    make_price(){
        let temp_price = this.price+'';
        let count = 1;
        let tmp = '';
        for(let i = temp_price.length-1; i >= 0;i--){
            // console.log(i,temp_price[i],temp_price);
            tmp += temp_price[i];
            if(count %3 == 0){
                tmp += ' ';
            }
            count++;
        }
        temp_price = '';
        for(let j = tmp.length - 1;j >= 0;j--){
            temp_price = temp_price + tmp[j];
        }
        // console.log(tmp,temp_price);
        this.price_html = temp_price;
    }
    insert_on_page(){
        let html = `
        <section class = 'sels_cats_info cat_${this.id}'>
            <div class="sels_cat">
                <div class="sels_wrap">
                    <div class="photo_cat">
                        <img src='${this.photo}' alt='${this.name}'>
                        <div class="top_info_about_cat">
                            <div class="discount ${this.discount>0?'':'not_show'}">
                                <p> - ${this.discount}%</p>
                            </div>
                            <div class="like">
                                <svg data-id="${this.id}" class="like ${this.liked?'liked':''}"width="46" height="42" viewBox="0 0 46 42" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path class="like" d="M33.7812 0.695312C31.2851 0.695312 28.9966 1.4863 26.9794 3.04634C25.0456 4.54197 23.758 6.44693 23 7.83214C22.242 6.44684 20.9544 4.54197 19.0206 3.04634C17.0034 1.4863 14.7149 0.695312 12.2188 0.695312C5.25298 0.695312 0 6.39293 0 13.9485C0 22.1112 6.55347 27.696 16.4746 36.1505C18.1593 37.5863 20.0689 39.2138 22.0538 40.9494C22.3154 41.1785 22.6514 41.3047 23 41.3047C23.3486 41.3047 23.6846 41.1785 23.9462 40.9495C25.9312 39.2136 27.8408 37.5862 29.5265 36.1496C39.4465 27.696 46 22.1112 46 13.9485C46 6.39293 40.747 0.695312 33.7812 0.695312Z" fill="white" fill-opacity="0.5"/>
                                    </svg>
                                    
                            </div>
                        </div>
                    </div>
                    <div class="main_info_about_cat">
                        <div class="info_wrap">
                            <h2 class='cat_color'>${this.name}</h2>
                            <div class="more_info">
                                <div class="cat_color_small">
                                    <p>${this.color}</p>
                                </div>
                                <div class='cat_years_div'>
                                    <p><span class = 'cat_years'>${this.years} мес.</span><p>
                                    <p>Возраст</p>
                                </div>
                                <div>
                                    <p> <span class = 'cat_hands'>4</span></p>
                                    <p>кол-во лап</p>
                                </div>
                            </div>
                            <h2 class = 'cat_price'>${this.price_html} руб.</h2>
                        </div>
                    </div>
                    <button class='cat_buy ${this.can_buy?'can':'cant'}'><p>Купить</p></button>
                </div>
            </div>
        </section>`;
        // console.log(html);
        place_for_cats[0].innerHTML += html;
    }
    insert_all_cats_high_to_low(){
        for(let i =0; i <array_with_cats.length;i++){
            
            array_with_cats[i].insert_on_page();
            if(!array_with_cats[i].isInsered){
                array_with_cats[i].onPage = document.getElementsByClassName(`cat_${array_with_cats[i].id}`);
                array_with_cats[i].isInsered = true;
            }
        }
    }
    insert_all_cats_low_to_high(){
        for(let i = array_with_cats.length -1; i >= 0;i--){
            array_with_cats[i].insert_on_page();
        }
    }
    sort_by_price(){
        for(let i = 0; i < array_with_cats.length;i++){
            for(let j =0;j<array_with_cats.length;j++){
                if(array_with_cats[i].price > array_with_cats[j].price){
                    let temp_obj = array_with_cats[j];
                    array_with_cats[j] = array_with_cats[i];
                    array_with_cats[i] = temp_obj;
                }
            }
        }
    }
    sort_by_years(){
        for(let i = 0; i < array_with_cats.length;i++){
            for(let j =0;j<array_with_cats.length;j++){
                if(array_with_cats[i].years > array_with_cats[j].years){
                    let temp_obj = array_with_cats[j];
                    array_with_cats[j] = array_with_cats[i];
                    array_with_cats[i] = temp_obj;
                }
            }
        }
    }
};

let array_with_cats = [];
let place_for_cats = document.getElementsByClassName('result_max_3');

// let new_my_cat = new Cat({photo:'https://static01.nyt.com/images/2020/04/22/science/22VIRUS-PETCATS1/merlin_150476541_233fface-f503-41af-9eae-d90a95eb6051-superJumbo.jpg?quality=90&auto=webp',
//                 name:'Мики',color:'Коричневый',price:27000,discount:'10',years:3,liked:true,can_buy:false});

// let new_my_cat2 = new Cat({photo:'https://static01.nyt.com/images/2020/04/22/science/22VIRUS-PETCATS1/merlin_150476541_233fface-f503-41af-9eae-d90a95eb6051-superJumbo.jpg?quality=90&auto=webp',
// name:'Мики',color:'Белый',price:28500,discount:'',years:3,liked:true,can_buy:false});


let cat_1 = new Cat({photo:'styles/img/sells_cat_1.jpg',
color:'Коричневый окрас',years:2,discount:40,liked:false,price:30000,name:'Кот полосатый',can_buy:true})
let cat_2 = new Cat({photo:'styles/img/sells_cat_2.jpg',
color:'Коричневый окрас',years:1,discount:4,liked:false,price:40000,name:'Кот полосатый',can_buy:false})
let cat_3 = new Cat({photo:'styles/img/sells_cat_3.jpg',
color:'Коричневый окрас',years:5,discount:15,liked:false,price:20000,name:'Кот полосатый',can_buy:true})
let cat_4 = new Cat({photo:'styles/img/sells_cat_1.jpg',
color:'Коричневый окрас',years:8,discount:99,liked:false,price:25000,name:'Кот полосатый',can_buy:true})
let cat_5 = new Cat({photo:'styles/img/sells_cat_3.jpg',
color:'Коричневый окрас',years:11,discount:1,liked:false,price:30000,name:'Кот полосатый',can_buy:true})
let cat_6 = new Cat({photo:'styles/img/sells_cat_2.jpg',
color:'Коричневый окрас',years:0,discount:8,liked:false,price:10000,name:'Кот полосатый',can_buy:false})

cat_1.insert_all_cats_high_to_low();




    